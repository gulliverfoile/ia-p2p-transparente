import random
import numpy as np
from typing import Dict, Tuple, List

class RolloutPlanner:
    def __init__(self, actions: List[str], depth: int = 4, n_rollouts: int = 30,
                 epsilon: float = 0.2, novelty_bonus_weight: float = 0.5):
        self.actions = actions
        self.depth = depth
        self.n_rollouts = n_rollouts
        self.epsilon = epsilon
        self.novelty_bonus_weight = novelty_bonus_weight

    def plan(self, state_repr: str, model, ethics, memory, extra_margin: float = 0.0) -> Tuple[str, float, Dict[str, float]]:
        best_action = None
        best_score = -1e9
        action_scores = {}

        for action in self.actions:
            scores = []
            for _ in range(self.n_rollouts):
                score = self._rollout(state_repr, action, model, memory)
                scores.append(score)
            avg_score = float(np.mean(scores))
            pred_next, pred_reward, hazard_risk = model.predict_next(state_repr, action)
            if pred_next is None:
                pred_reward = 0.0
                hazard_risk = 0.1
            uncertainty = 1.0 / (1.0 + model.state_counts.get(state_repr, 0))
            if not ethics.is_allowed(action, pred_reward + avg_score, hazard_risk, extra_margin, uncertainty):
                avg_score = -1e9
            action_scores[action] = avg_score
            if avg_score > best_score:
                best_score = avg_score
                best_action = action

        if best_action is None:
            best_action = random.choice(self.actions)
        return best_action, best_score, action_scores

    def _rollout(self, state: str, first_action: str, model, memory) -> float:
        total = 0.0
        cur = state
        action = first_action
        for step in range(self.depth):
            next_state, reward, _ = model.predict_next(cur, action)
            if next_state is None:
                total += 0.05 * (0.9 ** step)
                break
            total += reward * (0.9 ** step)
            cur = next_state
            if random.random() < self.epsilon:
                action = random.choice(self.actions)
            else:
                if 'symptom' in cur:
                    action = random.choice([a for a in self.actions if a.startswith('order_')] or self.actions)
                else:
                    action = random.choice(self.actions)
        novelty = self._novelty_bonus(state, memory)
        total += self.novelty_bonus_weight * novelty
        return total

    def _novelty_bonus(self, state: str, memory) -> float:
        similar = memory.query(state, topk=1)
        if not similar:
            return 1.0
        max_sim = similar[0][0]
        return max(0.0, 1.0 - max_sim)