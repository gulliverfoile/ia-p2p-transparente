import hashlib
import numpy as np
from collections import deque
from typing import List, Tuple, Optional

class TinyVectorizer:
    def __init__(self, dim: int = 128):
        self.dim = dim

    def embed(self, text: str) -> np.ndarray:
        v = np.zeros(self.dim)
        for token in text.split():
            h = hashlib.md5(token.encode()).hexdigest()
            idx = int(h, 16) % self.dim
            v[idx] += 1.0
        norm = np.linalg.norm(v)
        if norm > 0:
            v /= norm
        return v

class EpisodicMemory:
    def __init__(self, maxlen: int = 2000, vec_dim: int = 128):
        self.store = deque(maxlen=maxlen)
        self.vectorizer = TinyVectorizer(dim=vec_dim)

    def add(self, text: str, meta: Optional[dict] = None):
        emb = self.vectorizer.embed(text)
        self.store.append({'text': text, 'emb': emb, 'meta': meta or {}})

    def query(self, text: str, topk: int = 3) -> List[Tuple[float, dict]]:
        q = self.vectorizer.embed(text)
        sims = []
        for item in self.store:
            sim = np.dot(q, item['emb']) / (np.linalg.norm(q) * np.linalg.norm(item['emb']) + 1e-8)
            sims.append((sim, item['meta']))
        sims.sort(key=lambda x: x[0], reverse=True)
        return sims[:topk]