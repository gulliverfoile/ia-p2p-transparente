from collections import defaultdict, Counter
from typing import Dict, Tuple, Optional
import pickle
import os

class TabularWorldModel:
    def __init__(self, max_states: int = 10000):
        self.transitions = defaultdict(lambda: defaultdict(int))
        self.rewards = defaultdict(lambda: defaultdict(list))
        self.state_counts = Counter()
        self.max_states = max_states
        self.version = 0

    def observe(self, state: str, action: str, next_state: str, reward: float):
        self.transitions[(state, action)][next_state] += 1
        self.rewards[(state, action)].append(reward)
        self.state_counts[next_state] += 1
        if len(self.state_counts) > self.max_states:
            self._prune()

    def _prune(self):
        if len(self.state_counts) <= self.max_states:
            return
        to_remove = set()
        sorted_states = sorted(self.state_counts.items(), key=lambda x: x[1])
        for state, _ in sorted_states[:len(self.state_counts) - self.max_states]:
            to_remove.add(state)
        new_transitions = defaultdict(lambda: defaultdict(int))
        new_rewards = defaultdict(lambda: defaultdict(list))
        for (s, a), nxt_dict in self.transitions.items():
            if s in to_remove:
                continue
            for nxt, count in nxt_dict.items():
                if nxt not in to_remove:
                    new_transitions[(s, a)][nxt] = count
        for (s, a), rlist in self.rewards.items():
            if s not in to_remove:
                new_rewards[(s, a)] = rlist
        self.transitions = new_transitions
        self.rewards = new_rewards
        for state in to_remove:
            del self.state_counts[state]

    def predict_next(self, state: str, action: str) -> Tuple[Optional[str], float, float]:
        bucket = self.transitions.get((state, action), {})
        if not bucket:
            return None, 0.0, 0.0
        total = sum(bucket.values())
        next_state = max(bucket.items(), key=lambda x: x[1])[0]
        rewards = self.rewards.get((state, action), [0.0])
        avg_reward = sum(rewards) / len(rewards)
        hazard_count = sum(1 for s in bucket if 'harm' in s)
        hazard_risk = hazard_count / total if total > 0 else 0.0
        return next_state, avg_reward, hazard_risk

    def get_model_data(self) -> Dict:
        trans = {f"{s}|{a}": dict(bucket) for (s, a), bucket in self.transitions.items()}
        rew = {f"{s}|{a}": rewards for (s, a), rewards in self.rewards.items()}
        return {
            'transitions': trans,
            'rewards': rew,
            'state_counts': dict(self.state_counts),
            'version': self.version
        }

    def merge(self, other_data: Dict, weight: float = 0.5):
        self.version = max(self.version, other_data.get('version', 0)) + 1
        for key, bucket in other_data['transitions'].items():
            s, a = key.split('|')
            for s2, count in bucket.items():
                self.transitions[(s, a)][s2] += int(count * weight)
        for key, rew_list in other_data['rewards'].items():
            s, a = key.split('|')
            for r in rew_list:
                self.rewards[(s, a)].append(r)
        for state, cnt in other_data['state_counts'].items():
            self.state_counts[state] += int(cnt * weight)

    def save(self, filepath: str):
        with open(filepath, 'wb') as f:
            pickle.dump({
                'transitions': dict(self.transitions),
                'rewards': dict(self.rewards),
                'state_counts': dict(self.state_counts),
                'version': self.version
            }, f)

    def load(self, filepath: str):
        if os.path.exists(filepath):
            with open(filepath, 'rb') as f:
                data = pickle.load(f)
            self.transitions = defaultdict(lambda: defaultdict(int), data['transitions'])
            self.rewards = defaultdict(lambda: defaultdict(list), data['rewards'])
            self.state_counts = Counter(data['state_counts'])
            self.version = data.get('version', 0)