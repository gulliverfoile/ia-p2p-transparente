from typing import Dict, Callable, List
from collections import defaultdict
import threading
import time

class EventBus:
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._subscribers = defaultdict(list)
            cls._instance._lock = threading.Lock()
        return cls._instance

    def subscribe(self, event_type: str, callback: Callable[[Dict], None]):
        with self._lock:
            self._subscribers[event_type].append(callback)

    def emit(self, event: Dict):
        event_type = event.get('event_type')
        if not event_type:
            return
        if 'timestamp' not in event:
            event['timestamp'] = time.time()
        with self._lock:
            callbacks = self._subscribers.get(event_type, []) + self._subscribers.get('*', [])
        for cb in callbacks:
            try:
                cb(event)
            except Exception as e:
                print(f"Error en callback de {event_type}: {e}")