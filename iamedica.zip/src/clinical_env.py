"""
Entorno clínico con memoria de flujo temporal (ventana deslizante).
Cada observación guarda un historial de los últimos N pasos (síntomas y pruebas)
para que el agente pueda detectar tendencias (ej. fiebre creciente).
"""

import random
import numpy as np
from collections import deque
from typing import Dict, List, Any, Tuple
from src.environment import Environment

class ClinicalEnvironment(Environment):
    def __init__(self, config: Dict, seed: int = None, history_window: int = 3):
        """
        Args:
            config: diccionario con 'diseases', 'rewards', 'max_steps_per_episode'
            seed: semilla para reproducibilidad
            history_window: número de pasos anteriores a incluir en la representación
        """
        self.config = config
        self.diseases = config['diseases']
        self.rewards = config['rewards']
        self.max_steps = config.get('max_steps_per_episode', 15)
        self.history_window = history_window   # NUEVO
        self.seed = seed
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        self.reset()

    def reset(self):
        # Elegir enfermedad según prevalencia
        probs = [d['prevalence'] for d in self.diseases]
        self.true_disease = random.choices(self.diseases, weights=probs, k=1)[0]
        # Inicializar síntomas observados (algunos pueden no aparecer)
        self.observed_symptoms = []
        for symptom in self.true_disease['symptoms']:
            if random.random() < 0.8:
                self.observed_symptoms.append(symptom)
        self.tests_done = []
        self.diagnosis_made = None
        self.steps = 0
        self._harm_occurred = False

        # NUEVO: historial de observaciones (cada elemento es un dict con síntomas y pruebas)
        self.history = deque(maxlen=self.history_window)
        self._push_history()   # guarda el estado inicial

        return self._get_obs()

    def _get_obs(self) -> Dict:
        """Observación actual (sin historial, solo el momento presente)."""
        return {
            'symptoms': self.observed_symptoms.copy(),
            'tests_done': self.tests_done.copy(),
            'diagnosis': self.diagnosis_made,
            'step': self.steps,
            'harm_occurred': self._harm_occurred
        }

    def _push_history(self):
        """Añade la observación actual al historial."""
        obs = self._get_obs()
        # Guardamos una copia simplificada: solo sets de síntomas y pruebas
        self.history.append({
            'symptoms': set(obs['symptoms']),
            'tests': set(obs['tests_done'])
        })

    def get_state_repr(self, obs: Dict) -> str:
        """
        Representación del estado que incluye el flujo temporal.
        Se codifica:
        - síntomas actuales (ordenados)
        - pruebas actuales (ordenadas)
        - tendencias: para cada síntoma, si apareció, desapareció o se mantuvo
        - daño ocurrido
        """
        # Estado actual
        current_symptoms = set(obs['symptoms'])
        current_tests = set(obs['tests_done'])
        harm = 'harm' if obs.get('harm_occurred', False) else ''

        # Calcular tendencias si hay historial
        trends = []
        if len(self.history) >= 2:
            prev = self.history[-2]
            for sym in current_symptoms:
                if sym not in prev['symptoms']:
                    trends.append(f"{sym}+")   # apareció
            for sym in prev['symptoms']:
                if sym not in current_symptoms:
                    trends.append(f"{sym}-")   # desapareció
        # Para síntomas que se mantienen no añadimos nada (ahorra espacio)
        trend_str = ','.join(sorted(trends))

        # Construir representación
        sym_str = ','.join(sorted(current_symptoms))
        test_str = ','.join(sorted(current_tests))
        # Incluimos también la longitud del historial para dar contexto
        return f"s:{sym_str}|t:{test_str}|tr:{trend_str}|h:{harm}|histlen:{len(self.history)}"

    def step(self, action: str) -> Tuple[Dict, float, bool, dict]:
        self.steps += 1
        reward = 0.0
        info = {}
        done = False

        if action.startswith('predict_'):
            disease_name = action.split('_', 1)[1]
            if disease_name == self.true_disease['name']:
                reward = self.rewards['correct_diagnosis']
                info['correct'] = True
            else:
                reward = self.rewards['wrong_diagnosis']
                false_neg_cost = self.true_disease.get('false_negative_cost', 5.0)
                reward -= false_neg_cost
                info['correct'] = False
            done = True
            self.diagnosis_made = disease_name

        elif action.startswith('order_'):
            test_name = action.split('_', 1)[1]
            reward += self.rewards['unnecessary_test']
            if random.random() < 0.1:
                reward += self.rewards['harm_from_test']
                info['harm'] = True
                self._harm_occurred = True
            if test_name not in self.tests_done:
                self.tests_done.append(test_name)
            info['test_result'] = 'done'
        else:
            reward = -1.0

        if self.steps >= self.max_steps and not done:
            reward -= 5.0
            done = True

        # Actualizar historial después del paso
        obs = self._get_obs()
        self._push_history()

        return obs, reward, done, info