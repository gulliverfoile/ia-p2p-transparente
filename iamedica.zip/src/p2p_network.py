import socket
import threading
import pickle
import time
import random
import json
from typing import Dict, Tuple, Callable, Optional
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

class P2PNetwork:
    def __init__(self, agent_id: str, host: str = 'localhost', port: int = 0,
                 network_sim_config: Optional[Dict] = None, merge_weight: float = 0.5):
        self.agent_id = agent_id
        self.host = host
        self.port = port
        self.merge_weight = merge_weight
        self.sock = None
        self.running = False
        self.peers: Dict[str, Tuple[str, int, bytes]] = {}
        self.incoming_queue = []
        self.lock = threading.Lock()
        self.network_sim = network_sim_config or {'enabled': False}
        self.callback = None

    def start(self):
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind((self.host, self.port))
        self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        threading.Thread(target=self._listen, daemon=True).start()

    def _listen(self):
        while self.running:
            try:
                conn, addr = self.sock.accept()
                data = b''
                while True:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                conn.close()
                if data and self.callback:
                    if self.network_sim.get('enabled', False):
                        latency = random.gauss(self.network_sim.get('latency_ms_mean', 0),
                                               self.network_sim.get('latency_ms_std', 0))
                        latency = max(0, latency) / 1000.0
                        time.sleep(latency)
                        if random.random() < self.network_sim.get('packet_loss_rate', 0):
                            return
                        if random.random() < self.network_sim.get('corruption_rate', 0):
                            data = b'corrupted'
                    self.callback(data)
            except Exception:
                if self.running:
                    pass

    def send_model(self, peer_id: str, host: str, port: int, model_data: bytes):
        if peer_id in self.peers:
            host, port, _ = self.peers[peer_id]
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            sock.sendall(model_data)
            sock.close()
        except Exception:
            pass

    def add_peer(self, peer_id: str, host: str, port: int, public_key_hex: str):
        pubkey_bytes = bytes.fromhex(public_key_hex)
        self.peers[peer_id] = (host, port, pubkey_bytes)

    def set_message_callback(self, callback: Callable):
        self.callback = callback

    def stop(self):
        self.running = False
        if self.sock:
            self.sock.close()