import sqlite3
import json
import hashlib
from datetime import datetime
from typing import Dict, Optional
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from src.event_bus import EventBus

class AuditService:
    def __init__(self, agent_id: str, db_path: str, private_key: Ed25519PrivateKey):
        self.agent_id = agent_id
        self.db_path = db_path
        self.private_key = private_key
        self.last_hash = self._load_last_hash()
        self._init_db()
        bus = EventBus()
        bus.subscribe('*', self._on_event)

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute('''
            CREATE TABLE IF NOT EXISTS eventos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                tipo TEXT,
                datos TEXT,
                hash TEXT,
                hash_anterior TEXT,
                firma TEXT
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS estado (
                clave TEXT PRIMARY KEY,
                valor TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def _load_last_hash(self) -> Optional[str]:
        conn = sqlite3.connect(self.db_path)
        cur = conn.execute("SELECT valor FROM estado WHERE clave = 'last_hash'")
        row = cur.fetchone()
        conn.close()
        return row[0] if row else None

    def _save_last_hash(self, h: str):
        conn = sqlite3.connect(self.db_path)
        conn.execute("REPLACE INTO estado (clave, valor) VALUES (?, ?)", ("last_hash", h))
        conn.commit()
        conn.close()

    def _calculate_hash(self, tipo: str, datos: Dict) -> str:
        contenido = json.dumps({
            "tipo": tipo,
            "datos": datos,
            "timestamp": datetime.utcnow().isoformat()
        }, sort_keys=True, default=str)
        if self.last_hash:
            contenido += self.last_hash
        return hashlib.sha256(contenido.encode()).hexdigest()

    def _sign(self, msg: str) -> str:
        return self.private_key.sign(msg.encode()).hex()

    def _on_event(self, event: Dict):
        tipo = event.get('event_type', 'unknown')
        datos = event.get('payload', {})
        datos['source_agent'] = self.agent_id
        nuevo_hash = self._calculate_hash(tipo, datos)
        firma = self._sign(nuevo_hash)
        conn = sqlite3.connect(self.db_path)
        conn.execute(
            "INSERT INTO eventos (timestamp, tipo, datos, hash, hash_anterior, firma) VALUES (?, ?, ?, ?, ?, ?)",
            (datetime.utcnow().isoformat(), tipo, json.dumps(datos, default=str),
             nuevo_hash, self.last_hash, firma)
        )
        conn.commit()
        conn.close()
        self.last_hash = nuevo_hash
        self._save_last_hash(nuevo_hash)

    def verify_chain(self) -> bool:
        conn = sqlite3.connect(self.db_path)
        cur = conn.execute("SELECT hash, hash_anterior FROM eventos ORDER BY id")
        rows = cur.fetchall()
        conn.close()
        prev = None
        for h, prev_hash in rows:
            if prev_hash != prev:
                return False
            prev = h
        return True