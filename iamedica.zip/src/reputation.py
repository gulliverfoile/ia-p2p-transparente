from typing import Dict

class ReputationManager:
    def __init__(self, initial: float = 0.5, update_rate: float = 0.1, exclusion_threshold: float = 0.2):
        self.reputations: Dict[str, float] = {}
        self.initial = initial
        self.update_rate = update_rate
        self.exclusion_threshold = exclusion_threshold
        self.excluded: set = set()

    def get_reputation(self, peer_id: str) -> float:
        if peer_id in self.excluded:
            return 0.0
        return self.reputations.get(peer_id, self.initial)

    def update(self, peer_id: str, delta: float):
        if peer_id in self.excluded:
            return
        current = self.get_reputation(peer_id)
        new = current + self.update_rate * delta
        new = max(0.0, min(1.0, new))
        self.reputations[peer_id] = new
        if new < self.exclusion_threshold:
            self.excluded.add(peer_id)

    def is_excluded(self, peer_id: str) -> bool:
        return peer_id in self.excluded