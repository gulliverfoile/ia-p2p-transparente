import os
import pickle
import json
import time
import random
import numpy as np
from typing import Dict, Optional
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from src.event_bus import EventBus
from src.audit_service import AuditService
from src.world_model import TabularWorldModel
from src.ethical_module import EthicalModule
from src.memory import EpisodicMemory
from src.planner import RolloutPlanner
from src.reputation import ReputationManager
from src.p2p_network import P2PNetwork
from src.environment import Environment
from src.utils import setup_logger

class PrudentialAgent:
    def __init__(self, agent_id: str, config: Dict, env: Environment, data_dir: str = "./data"):
        self.agent_id = agent_id
        self.config = config
        self.env = env
        self.data_dir = os.path.join(data_dir, agent_id)
        os.makedirs(self.data_dir, exist_ok=True)

        self.logger = setup_logger(agent_id)

        # Claves Ed25519
        key_file = os.path.join(self.data_dir, "private_key.pem")
        if os.path.exists(key_file):
            with open(key_file, "rb") as f:
                self.private_key = Ed25519PrivateKey.from_private_bytes(f.read())
        else:
            self.private_key = Ed25519PrivateKey.generate()
            with open(key_file, "wb") as f:
                f.write(self.private_key.private_bytes_raw())
        self.public_key = self.private_key.public_key()
        self.public_key_bytes = self.public_key.public_bytes_raw()

        self.event_bus = EventBus()
        db_path = os.path.join(self.data_dir, "audit.db")
        self.audit = AuditService(agent_id, db_path, self.private_key)

        # World Model
        wm_config = config.get('world_model', {})
        self.world_model = TabularWorldModel(max_states=wm_config.get('max_states', 10000))
        model_path = os.path.join(self.data_dir, "model.pkl")
        if os.path.exists(model_path):
            self.world_model.load(model_path)
            self.logger.info("Modelo cargado desde disco")

        # Ethics
        eth_config = config.get('ethics', {})
        self.ethics = EthicalModule(
            min_safe_margin=eth_config.get('min_safe_margin', 2.0),
            hazard_penalty=eth_config.get('hazard_penalty', -5.0),
            dynamic_margin=eth_config.get('dynamic_margin', True),
            uncertainty_factor=eth_config.get('uncertainty_factor', True)
        )

        # Memory
        mem_config = config.get('memory', {})
        self.memory = EpisodicMemory(maxlen=mem_config.get('maxlen', 2000),
                                     vec_dim=mem_config.get('vec_dim', 128))

        # Planner: generar acciones dinámicamente desde el entorno clínico
        if config['environment']['type'] == 'clinical':
            diseases = config['environment']['clinical_config']['diseases']
            tests = set()
            for d in diseases:
                for t in d.get('tests', []):
                    tests.add(t)
            self.actions = [f"predict_{d['name']}" for d in diseases] + [f"order_{t}" for t in tests]
        else:
            self.actions = ['up', 'down', 'left', 'right', 'stay', 'pickup']  # fallback
        planner_config = config.get('planner', {})
        self.planner = RolloutPlanner(
            actions=self.actions,
            depth=planner_config.get('depth', 4),
            n_rollouts=planner_config.get('n_rollouts', 30),
            epsilon=planner_config.get('epsilon', 0.2),
            novelty_bonus_weight=planner_config.get('novelty_bonus_weight', 0.5)
        )

        # Reputation
        rep_config = config.get('reputation', {})
        self.reputation = ReputationManager(
            initial=rep_config.get('initial_reputation', 0.5),
            update_rate=rep_config.get('update_rate', 0.1),
            exclusion_threshold=rep_config.get('exclusion_threshold', 0.2)
        )

        # P2P
        p2p_config = config.get('p2p', {})
        self.p2p_enabled = p2p_config.get('enabled', False)
        self.p2p = None
        if self.p2p_enabled:
            self.p2p = P2PNetwork(
                agent_id,
                host=p2p_config.get('listen_host', 'localhost'),
                port=p2p_config.get('listen_port', 0),
                network_sim_config=p2p_config.get('network_simulation', {}),
                merge_weight=p2p_config.get('merge_weight', 0.5)
            )
            self.p2p.set_message_callback(self._on_p2p_message)
            self.p2p.start()
            self.logger.info(f"P2P iniciado en puerto {self.p2p.port}")

        # Pesos adaptativos
        self.weights = {'plato': 3.0, 'meme': 0.2, 'wuwei': 0.5}
        self.prev_weights = self.weights.copy()
        self.lr_weights = config['agent'].get('lr_weights', 0.005)
        self.cost_change_penalty = config['agent'].get('cost_change_penalty', 0.05)
        self.historical_performance = []
        self.cold_start_episodes = config['agent'].get('cold_start_episodes', 5)
        self.episode_count = 0
        self.step_counter = 0
        self.share_interval = p2p_config.get('gossip_interval_steps', 10)
        self.validation_buffer = []
        self.min_validation = rep_config.get('min_validation_episodes', 5)

        self._emit('AGENT_INIT', {'agent_id': agent_id})

    def _emit(self, event_type: str, payload: Dict):
        self.event_bus.emit({'event_type': event_type, 'source': self.agent_id, 'payload': payload})

    def _on_p2p_message(self, raw_data: bytes):
        try:
            msg = pickle.loads(raw_data)
            if msg['type'] == 'model_share':
                peer_id = msg['sender_id']
                if peer_id not in self.p2p.peers:
                    return
                pubkey_bytes = self.p2p.peers[peer_id][2]
                pub_key = Ed25519PublicKey.from_public_bytes(pubkey_bytes)
                contenido = json.dumps({k:v for k,v in msg.items() if k != 'signature'}, sort_keys=True)
                pub_key.verify(bytes.fromhex(msg['signature']), contenido.encode())
                with self.p2p.lock:
                    self.p2p.incoming_queue.append(msg)
        except Exception as e:
            self.logger.warning(f"Error en mensaje P2P: {e}")

    def _process_incoming_models(self):
        if not self.p2p:
            return
        with self.p2p.lock:
            queue = self.p2p.incoming_queue[:]
            self.p2p.incoming_queue.clear()
        for msg in queue:
            self._merge_model_from_peer(msg)

    def _merge_model_from_peer(self, msg: Dict):
        peer_id = msg['sender_id']
        if self.reputation.is_excluded(peer_id):
            self.logger.info(f"Ignorando modelo de peer excluido {peer_id}")
            return
        model_data = msg['model_data']
        if len(self.validation_buffer) >= self.min_validation:
            improvement = self._evaluate_model_improvement(model_data)
            if improvement > 0:
                weight = self.p2p.merge_weight * self.reputation.get_reputation(peer_id)
                self.world_model.merge(model_data, weight=weight)
                self._emit('MODEL_MERGE_ACCEPTED', {'peer': peer_id, 'improvement': improvement})
                self.reputation.update(peer_id, delta=improvement)
            else:
                self._emit('MODEL_MERGE_REJECTED', {'peer': peer_id, 'reason': 'no improvement'})
                self.reputation.update(peer_id, delta=-0.1)
        else:
            self.world_model.merge(model_data, weight=0.2)
            self._emit('MODEL_MERGE_ACCEPTED', {'peer': peer_id, 'improvement': 0.0})

    def _evaluate_model_improvement(self, external_model_data: Dict) -> float:
        if len(self.validation_buffer) == 0:
            return 0.0
        total_error_current = 0.0
        total_error_external = 0.0
        n = 0
        for (state, action, true_next, true_reward, _) in self.validation_buffer:
            _, pred_reward_cur, _ = self.world_model.predict_next(state, action)
            total_error_current += abs(pred_reward_cur - true_reward)
            key = f"{state}|{action}"
            if key in external_model_data.get('rewards', {}):
                ext_rewards = external_model_data['rewards'][key]
                pred_reward_ext = sum(ext_rewards)/len(ext_rewards) if ext_rewards else 0.0
                total_error_external += abs(pred_reward_ext - true_reward)
            else:
                total_error_external += abs(0.0 - true_reward)
            n += 1
        if n == 0:
            return 0.0
        error_cur = total_error_current / n
        error_ext = total_error_external / n
        return (error_cur - error_ext) / (error_cur + 1e-8)

    def reset_for_episode(self):
        obs = self.env.reset()
        self.current_obs = obs
        self.current_state = self.env.get_state_repr(obs)
        self.episode_reward = 0.0
        self.episode_count += 1
        self._emit('EPISODE_START', {'episode': self.episode_count, 'state': self.current_state})
        return obs

    def step(self):
        self._process_incoming_models()
        ethical_margin_boost = self.weights['plato'] * 0.1
        if self.episode_count <= self.cold_start_episodes:
            ethical_margin_boost = 100.0

        action, score, action_scores = self.planner.plan(
            self.current_state, self.world_model, self.ethics, self.memory, ethical_margin_boost
        )
        self._emit('ACTION_SELECTED', {'state': self.current_state, 'action': action, 'score': score})

        next_obs, reward, done, info = self.env.step(action)
        next_state = self.env.get_state_repr(next_obs)

        self.world_model.observe(self.current_state, action, next_state, reward)
        self.memory.add(f"{self.current_state} -> {action} -> {next_state} r={reward}", meta=info)

        self.episode_reward += reward
        self.step_counter += 1

        self._emit('STEP_TAKEN', {
            'state': self.current_state,
            'action': action,
            'next_state': next_state,
            'reward': reward,
            'info': info
        })

        self.validation_buffer.append((self.current_state, action, next_state, reward, info))
        if len(self.validation_buffer) > 200:
            self.validation_buffer = self.validation_buffer[-200:]

        if self.p2p and self.p2p_enabled and self.step_counter % self.share_interval == 0:
            self._share_model()

        self.current_obs = next_obs
        self.current_state = next_state

        if done:
            self._end_episode()
        return next_obs, reward, done, info

    def _share_model(self):
        model_data = self.world_model.get_model_data()
        msg = {
            'type': 'model_share',
            'sender_id': self.agent_id,
            'model_data': model_data,
            'timestamp': time.time()
        }
        contenido = json.dumps({k:v for k,v in msg.items() if k != 'signature'}, sort_keys=True, default=str)
        signature = self.private_key.sign(contenido.encode()).hex()
        msg['signature'] = signature
        data = pickle.dumps(msg)
        for peer_id, (host, port, _) in self.p2p.peers.items():
            self.p2p.send_model(peer_id, host, port, data)
        self._emit('MODEL_SHARED', {'peers': list(self.p2p.peers.keys())})

    def _end_episode(self):
        improvement = 0.0
        if len(self.historical_performance) > 0:
            prev_avg = np.mean(self.historical_performance)
            if prev_avg != 0:
                improvement = (self.episode_reward - prev_avg) / abs(prev_avg)
        if improvement > 0:
            for k in self.weights:
                self.weights[k] *= (1 + self.lr_weights * improvement)
        else:
            neutros = {'plato': 3.0, 'meme': 0.2, 'wuwei': 0.5}
            for k in self.weights:
                self.weights[k] = (1 - self.lr_weights) * self.weights[k] + self.lr_weights * neutros[k]
        for k, (low, high) in [('plato', (1.0,10.0)), ('meme', (0.05,2.0)), ('wuwei', (0.1,3.0))]:
            self.weights[k] = np.clip(self.weights[k], low, high)
        self.prev_weights = self.weights.copy()
        self.historical_performance.append(self.episode_reward)
        self._emit('EPISODE_END', {
            'episode': self.episode_count,
            'reward': self.episode_reward,
            'improvement': improvement,
            'weights': self.weights
        })
        model_path = os.path.join(self.data_dir, "model.pkl")
        self.world_model.save(model_path)
        self.logger.info(f"Episodio {self.episode_count} reward: {self.episode_reward:.2f}")

    def close(self):
        if self.p2p:
            self.p2p.stop()
        self._emit('AGENT_STOP', {'final_weights': self.weights})
4. Script de demo (demo_clinical.py) – sin cambios, pero ahora el entorno usará history_window
python
#!/usr/bin/env python3
import sys
import os